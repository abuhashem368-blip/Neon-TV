// ===== NEON TV - Main Script =====

document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    initMobileMenu();
    initCounters();
    renderLiveStreams();
    renderCreators();
    initSmoothScroll();
});

// Mobile Menu Toggle
function initMobileMenu() {
    const toggle = document.getElementById('menuToggle');
    const links = document.getElementById('navLinks');

    if (toggle && links) {
        toggle.addEventListener('click', () => {
            links.classList.toggle('open');
            toggle.textContent = links.classList.contains('open') ? '✕' : '☰';
        });

        // Close on link click
        links.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                links.classList.remove('open');
                toggle.textContent = '☰';
            });
        });
    }
}

// Animated Counters
function initCounters() {
    const counters = document.querySelectorAll('.stat-number');
    
    const animateCounter = (el) => {
        const target = parseFloat(el.dataset.target);
        const isDecimal = target % 1 !== 0;
        const duration = 2000;
        const start = performance.now();

        const update = (now) => {
            const progress = Math.min((now - start) / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3);
            const current = target * ease;

            if (isDecimal) {
                el.textContent = current.toFixed(1);
            } else {
                el.textContent = Math.floor(current).toLocaleString();
            }

            if (progress < 1) {
                requestAnimationFrame(update);
            } else {
                el.textContent = isDecimal ? target.toFixed(1) : target.toLocaleString();
            }
        };

        requestAnimationFrame(update);
    };

    // Trigger when in view
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(c => observer.observe(c));
}

// Live Streams Data
const streams = [
    { title: "Cyberpunk 2077 Speedrun WR Attempts", channel: "NeonRunner", category: "Gaming", viewers: "12.4K", emoji: "🎮" },
    { title: "AI Neural Network Live Build", channel: "CodeVoid", category: "Tech & AI", viewers: "8.7K", emoji: "⚡" },
    { title: "Synthwave Live Set — Neon Nights", channel: "PulseWave", category: "Music", viewers: "21.3K", emoji: "🎵" },
    { title: "Global News Desk — Breaking", channel: "SignalFeed", category: "News", viewers: "34.1K", emoji: "📡" },
    { title: "Digital Art Commission Stream", channel: "PixelForge", category: "Creative", viewers: "5.2K", emoji: "🎨" },
    { title: "Tokyo Night Walk — IRL", channel: "WanderBot", category: "IRL", viewers: "18.9K", emoji: "🌍" },
    { title: "Valorant Ranked Grind — Radiant", channel: "ApexNova", category: "Esports", viewers: "27.6K", emoji: "🏆" },
    { title: "Late Night Talks with AI Guests", channel: "EchoChamber", category: "Talk Shows", viewers: "9.4K", emoji: "💬" },
];

function renderLiveStreams() {
    const grid = document.getElementById('liveStreams');
    if (!grid) return;

    grid.innerHTML = streams.map(s => `
        <div class="stream-card">
            <div class="stream-thumb" data-emoji="${s.emoji}">
                <span class="stream-live">LIVE</span>
                <span class="stream-viewers">${s.viewers} watching</span>
            </div>
            <div class="stream-body">
                <h3 class="stream-title">${s.title}</h3>
                <div class="stream-meta">
                    <span class="stream-channel">${s.channel}</span>
                    <span class="stream-category">${s.category}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Creators Data
const creators = [
    { name: "CyberNexus", followers: "1.2M", initials: "CN", online: true },
    { name: "NovaPulse", followers: "890K", initials: "NP", online: true },
    { name: "VoidWalker", followers: "654K", initials: "VW", online: false },
    { name: "AetherX", followers: "1.5M", initials: "AX", online: true },
    { name: "GlitchQueen", followers: "720K", initials: "GQ", online: true },
    { name: "NeonSamurai", followers: "980K", initials: "NS", online: false },
];

function renderCreators() {
    const grid = document.getElementById('creatorsGrid');
    if (!grid) return;

    grid.innerHTML = creators.map(c => `
        <div class="creator-card">
            <div class="creator-avatar ${c.online ? 'online' : ''}">${c.initials}</div>
            <h3 class="creator-name">${c.name}</h3>
            <p class="creator-followers">${c.followers} followers</p>
            <button class="btn-glow btn-outline btn-sm">Follow</button>
        </div>
    `).join('');
}

// Smooth Scroll for nav links
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
}

// Simple particle effect
function initParticles() {
    const container = document.getElementById('particles');
    if (!container) return;

    for (let i = 0; i < 40; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: absolute;
            width: ${Math.random() * 3 + 1}px;
            height: ${Math.random() * 3 + 1}px;
            background: ${Math.random() > 0.5 ? '#00f0ff' : '#ff00aa'};
            border-radius: 50%;
            opacity: ${Math.random() * 0.4 + 0.1};
            left: ${Math.random() * 100}%;
            top: ${Math.random() * 100}%;
            animation: float ${Math.random() * 15 + 10}s linear infinite;
            box-shadow: 0 0 ${Math.random() * 6 + 2}px currentColor;
        `;
        container.appendChild(particle);
    }

    // Add keyframes
    const style = document.createElement('style');
    style.textContent = `
        @keyframes float {
            0% { transform: translateY(0) translateX(0); opacity: 0; }
            10% { opacity: 0.4; }
            90% { opacity: 0.4; }
            100% { transform: translateY(-100vh) translateX(${Math.random() * 100 - 50}px); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}
